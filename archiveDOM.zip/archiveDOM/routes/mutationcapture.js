var express = require('express');
var router = express.Router();
var fs =  require('fs');
var mkdirp = require('mkdirp');

router.post('/', function(req, res, next) {
  console.log('inside capture1');
  //var path = '/Users/ctsuser/Documents/Jagdish/dpf/coverstory/repository/' + req.body.meId + '/' + req.body.date + '/' + req.body.jsessionID + '/screens';
  var path = '/Users/ctsuser1/Documents/documents/Jagdish/dpf/replaytool/rrweb-master/events';
  console.log(path);
    mkdirp(path, function (err) {
      var timeStamp = new Date().getTime();
      var fileName = path + '/' + timeStamp + '.json';
      //var fileName = path + '/' + req.body.timeFrame + '.html';
      //console.log(fileName);
      //console.log(JSON.stringify(req.body));
	  var tempJSON = JSON.stringify(req.body);
		      fs.writeFile(fileName, tempJSON, function (err) {
				if (err) console.log(err);
				res.send('recorded successfully');
			  });

    });
});

module.exports = router;
